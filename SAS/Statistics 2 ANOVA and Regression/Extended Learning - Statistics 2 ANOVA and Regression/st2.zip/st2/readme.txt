The programs in this folder are for the class on 
Statistics 2: ANOVA and Regression

You need to open and submit the program ST200d01.sas before running any of the programs.  
The program ST200d01.sas generates all of the SAS data sets for this course 
and stores them in the STAT2 library.
 
The demonstration programs, solutions to the exercises, and the appendix programs are also provided.

 =============================================================================

 Copyright (c) 2017 SAS Institute Inc.                                       
 Cary, N.C. USA 27513-8000                                                    
 all rights reserved                                                          
                                                                              
 THE INFORMATION CONTAINED IN THIS DISTRIBUTION IS PROVIDED BY THE INSTITUTE      
 "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING 
 BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
 A PARTICULAR PURPOSE.  RECIPIENTS ACKNOWLEDGE AND AGREE THAT THE INSTITUTE   
 SHALL NOT BE LIABLE WHATSOEVER FOR ANY DAMAGES ARISING OUT OF THEIR USE OF   
 THIS INFORMATION.                                                            
                                                                            
                                                   
                                                                            
